#include "date.h"

date::date(){year_ = 0; month_=0;day_=0}

